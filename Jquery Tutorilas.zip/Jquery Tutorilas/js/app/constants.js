var FieldNames = {
	ACCESS_TOKEN : "access_token",
	REFRESH_TOKEN : "refresh_token",
	ACCESS_TOKEN_TIMESTAMP : "access_token_timestamp",
	ACCESS_TOKEN_ENDPOINT: "ACCESS_TOKEN_ENDPOINT",
	REFRESH_TOKEN_ENDPOINT: "REFRESH_TOKEN_ENDPOINT",
	HOSTED_START_PAGE_ADDR: "HOSTED_MAIN_PAGE_ADDRESS",
	HOSTED_MAIN_PAGE_ADDR : "HOSTED_MAIN_PAGE_ADDR",
	BOARDS: "BOARDS",
	USER_ENDPOINT: "USER_ENDPOINT",
	REDIRECT_URL: "REDIRECT_URL",
	USER_ID: "user_id"
};

var Constants = {
	THRESHOLD_BUFFER_TIME_MS  :  (12 * 60 * 60 * 1000) ,
	APP_SECRET  :  "067bfdd2-0da8-45fd-90f0-12a242f9e6f9", 
	APP_ID  :  "1f2767af-9447-4f67-8bad-63978eb7d94d",
	PRIME_SERVER_ADDR  :  "https://captivateprimeqe.adobe.com/", 
	MY_APP_HOSTED_SERVER_BASE_ADDR  :  "http://localhost:8085/",
	SCOPE  :  "learner:read,learner:write",
	OCODE_DATA  :  "state1",
	SOURCE_FOLDER  :  "PrimeApp/",
	MAIN_PAGE  :  "oauthredirect.html",
	START_PAGE : "index.html",
	API_VERSION: "primeapi/v2/"
};